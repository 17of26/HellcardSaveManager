﻿namespace HellcardSaveManager
{
    public partial class MainView
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
